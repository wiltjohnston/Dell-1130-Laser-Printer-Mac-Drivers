bResolution = true;

bQuality = true;

bImage = true;

bColor = true;

bDarkness = true;

bTonersave = true;

bReprint = true;

bHighaltitude = true;

bPowersave = true;

bAboutButtons =  true;

bPaper = true;

bJobProof = true;

bBlackOptimization = true;

bPageColorSetting = true;

bJobAccountingEncryption = true;